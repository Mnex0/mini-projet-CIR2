
#include "CityPoint.h"

class City
{
public:
    City();
    ~City() {};

private:
    CityPoint point;
};