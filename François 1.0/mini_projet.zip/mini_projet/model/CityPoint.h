

class CityPoint
{
public:
    CityPoint();
    ~CityPoint() {};

private:
    float lon;
    float lat;
};