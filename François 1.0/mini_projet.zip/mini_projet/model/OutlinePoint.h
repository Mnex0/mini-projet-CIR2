

class OutlinePoint
{
public:
    OutlinePoint(float lon, float lat);
    ~OutlinePoint() {};

private:
    float lon;
    float lat;
};