
#include <mysql_driver.h>
#include <mysql_connection.h>
#include <cppconn/prepared_statement.h>

#include "DB.h"

using namespace std;

DB::DB(string host, string dbName, string username, string password) {
    
}