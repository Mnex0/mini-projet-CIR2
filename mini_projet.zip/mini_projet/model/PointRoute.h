

class RoutePoint
{
public:
    RoutePoint();
    ~RoutePoint() {};

private:
    float lon;
    float lat;
};