

class PointContour
{
public:
    PointContour(float lon, float lat);
    ~PointContour() {};

private:
    float lon;
    float lat;
};