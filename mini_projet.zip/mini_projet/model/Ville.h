
#include "PointVille.h"

class Ville
{
public:
    Ville();
    ~Ville() {};

private:
    PointVille point;
};