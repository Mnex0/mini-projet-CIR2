

class PointVille
{
public:
    PointVille();
    ~PointVille() {};

private:
    float lon;
    float lat;
};