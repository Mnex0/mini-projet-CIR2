
#include "BDD.h"

using namespace std;

BDD::BDD(string host, string dbName, string username, string password)
{
}